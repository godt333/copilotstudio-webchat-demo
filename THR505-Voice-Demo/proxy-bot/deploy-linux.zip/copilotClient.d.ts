/**
 * Copilot Studio Direct Line Client
 * ==================================
 * Manages the connection to Copilot Studio via Direct Line API.
 *
 * This client handles:
 * - Token acquisition from Copilot Studio
 * - Starting conversations
 * - Sending messages to Copilot Studio
 * - Receiving responses
 * - Managing conversation state
 */
/**
 * Direct Line activity (message)
 */
interface Activity {
    type: string;
    id?: string;
    timestamp?: string;
    localTimestamp?: string;
    channelId?: string;
    from: {
        id: string;
        name?: string;
        role?: string;
    };
    conversation?: {
        id: string;
    };
    recipient?: {
        id: string;
        name?: string;
    };
    text?: string;
    speak?: string;
    inputHint?: string;
    attachments?: any[];
    suggestedActions?: any;
    value?: any;
    locale?: string;
}
/**
 * Conversation session tracking
 */
interface ConversationSession {
    conversationId: string;
    token: string;
    watermark: string;
    createdAt: Date;
}
/**
 * CopilotClient manages conversations with Copilot Studio
 */
export declare class CopilotClient {
    private tokenEndpoint;
    private directLineSecret?;
    private sessions;
    private directLineUrl;
    constructor(config: {
        tokenEndpoint?: string;
        directLineSecret?: string;
    });
    /**
     * Get or create a conversation session for a user
     */
    getOrCreateSession(userId: string): Promise<ConversationSession>;
    /**
     * Start a new conversation with Copilot Studio
     */
    private startConversation;
    /**
     * Send a message to Copilot Studio and get the response
     */
    sendMessage(userId: string, text: string, locale?: string): Promise<Activity[]>;
    /**
     * Poll Direct Line for bot responses
     */
    private pollForResponses;
    /**
     * End a conversation session
     */
    endSession(userId: string): void;
    /**
     * Utility delay function
     */
    private delay;
}
export default CopilotClient;
//# sourceMappingURL=copilotClient.d.ts.map