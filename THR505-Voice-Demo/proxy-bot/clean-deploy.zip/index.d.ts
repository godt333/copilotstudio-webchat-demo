/**
 * DLS Proxy Bot - Entry Point
 * ============================
 * Main entry point for the Direct Line Speech proxy bot.
 *
 * This server:
 * - Hosts the Bot Framework messaging endpoint
 * - Handles authentication with Azure Bot Service
 * - Routes activities to the ProxyBot
 *
 * The bot is designed to be deployed to Azure App Service
 * and connected to a Direct Line Speech channel.
 */
export {};
//# sourceMappingURL=index.d.ts.map