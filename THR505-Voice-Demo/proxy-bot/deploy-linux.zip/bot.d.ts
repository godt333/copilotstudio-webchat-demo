/**
 * DLS Proxy Bot
 * =============
 * Bot Framework bot that proxies messages between Direct Line Speech
 * and Copilot Studio.
 *
 * This bot:
 * 1. Receives messages via Direct Line Speech channel
 * 2. Forwards them to Copilot Studio via Direct Line
 * 3. Returns Copilot Studio's responses back to the user
 *
 * The DLS channel handles all speech recognition and synthesis,
 * so this bot only deals with text activities.
 */
import { ActivityHandler, TurnContext, ConversationState, UserState } from 'botbuilder';
import { CopilotClient } from './copilotClient';
/**
 * ProxyBot - Forwards messages between DLS and Copilot Studio
 */
export declare class ProxyBot extends ActivityHandler {
    private copilotClient;
    private conversationState;
    private userState;
    private sessionAccessor;
    constructor(copilotClient: CopilotClient, conversationState: ConversationState, userState: UserState);
    /**
     * Handle incoming message and forward to Copilot Studio
     */
    private handleMessage;
    /**
     * Save state changes at the end of each turn
     */
    run(context: TurnContext): Promise<void>;
}
export default ProxyBot;
//# sourceMappingURL=bot.d.ts.map